<?php

namespace App\Controllers;

use App\Models\MataKuliahModel;

class Matakuliah extends BaseController
{
    public function index()
    {
        //object model mata kuliah
        $this->mtk1 = new MataKuliahModel();
        $this->mtk2 = new MataKuliahModel();
        $this->mtk3 = new MataKuliahModel();

        //memberikan nilai kepada object
        $this->mtk1->id = 1;
        $this->mtk1->kode = "00001";
        $this->mtk1->nama = "Pemrograman Web 2";
        $this->mtk1->sks = "3";

        $this->mtk2->id = 2;
        $this->mtk2->kode = "00001";
        $this->mtk2->nama = "Pemrograman Web 2";
        $this->mtk2->sks = "3";

        $this->mtk3->id = 3;
        $this->mtk3->kode = "00001";
        $this->mtk3->nama = "Pemrograman Web 2";
        $this->mtk3->sks = "3";

        $list_mtk = [$this->mtk1, $this->mtk2, $this->mtk3];
        $data['list_mtk'] = $list_mtk;

        //return sebuah view dan mengirimkan sebuah data array
        return view('matakuliah/index', $data);
    }
}
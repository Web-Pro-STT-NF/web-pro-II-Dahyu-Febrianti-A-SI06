
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=<!-- Main content -->
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
    <!-- icheck bootstrap -->
    <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/adminlte.min.css">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Suplier</title>
</head>
	
<body>
<h3 class="text-center">Data Suplier</h3>
<div class="container px-4">
  <div class="row gx-5">
    <div class="col">
     <div class="p-3 border bg-light">
         <!-- Profile Image -->
         <div class="card card-outline" style="color: #F2623A;">
              <div class="card-body box-profile">
                <div class="text-center">
                  <img class="profile-user-img img-fluid img-circle"
                       src="assets/img/portfolio/thumbnails/dahyu.jpg"
                       alt="User profile picture">
                </div>

                <h3 class="profile-username text-center">Dahyu Febrianti Ambarisna</h3>

                <p class="text-muted text-center">0110121125</p>

                <ul class="list-group list-group-unbordered mb-3">
                  <li class="list-group-item">
                    <b>Domisili</b> <a class="float-right">Bandung</a>
                  </li>
                  <li class="list-group-item">
                    <b>Nomor</b> <a class="float-right">0895351464256</a>
                  </li>
                  <li class="list-group-item">
                    <b>Jobdec</b> <a class="float-right">usesr & pesanan</a>
                  </li>
                </ul>

                <a href="#" class="btn btn-block " style="background-color: #F2623A; color: white;"><b>Setting</b></a>
              </div>
              <!-- /.card-body -->
     </div>
    </div>
    <div class="col">
      <div class="p-3 border bg-light">
          <!-- Profile Image -->
         <div class="card card-outline" style="color: #F2623A;">
              <div class="card-body box-profile">
                <div class="text-center">
                  <img class="profile-user-img img-fluid img-circle"
                       src="assets/img/portfolio/thumbnails/eka.png"
                       alt="User profile picture">
                </div>

                <h3 class="profile-username text-center">Eka Ahmalia</h3>

                <p class="text-muted text-center">0110121121</p>

                <ul class="list-group list-group-unbordered mb-3">
                  <li class="list-group-item">
                    <b>Domisili</b> <a class="float-right">Depok</a>
                  </li>
                  <li class="list-group-item">
                    <b>Nomor</b> <a class="float-right">089677999214</a>
                  </li>
                  <li class="list-group-item">
                    <b>Jobdec</b> <a class="float-right">produk & jenis produk</a>
                  </li>
                </ul>

                <a href="#" class="btn btn-block " style="background-color: #F2623A; color: white;"><b>Setting</b></a>
              </div>
              <!-- /.card-body -->
      </div>
    </div>
    <div class="col">
     <div class="p-3 border bg-light">
         <!-- Profile Image -->
         <div class="card card-outline" style="color: #F2623A;">
         <div class="card-body box-profile">
                <div class="text-center">
                  <img class="profile-user-img img-fluid img-circle"
                       src="assets/img/portfolio/thumbnails/fani.jpg"
                       alt="User profile picture">
                </div>

                <h3 class="profile-username text-center">Fani Hilwa Agustin</h3>

                <p class="text-muted text-center">0110121130</p>

                <ul class="list-group list-group-unbordered mb-3">
                  <li class="list-group-item">
                    <b>Domisili</b> <a class="float-right">Depok</a>
                  </li>
                  <li class="list-group-item">
                    <b>Nomor</b> <a class="float-right">085819069224</a>
                  </li>
                  <li class="list-group-item">
                    <b>Jobdec</b> <a class="float-right">pembelian</a>
                  </li>
                </ul>

                <a href="#" class="btn btn-block " style="background-color: #F2623A; color: white;"><b>Setting</b></a>
              </div>
              <!-- /.card-body -->
     </div>
    </div>
    <div class="col">
      <div class="p-3 border bg-light">
          <!-- Profile Image -->
         <div class="card card-outline" style="color: #F2623A;">
         <div class="card-body box-profile">
                <div class="text-center">
                  <img class="profile-user-img img-fluid img-circle"
                       src="assets/img/portfolio/thumbnails/nana.png"
                       alt="User profile picture">
                </div>

                <h3 class="profile-username text-center">Nashwa Putri Sabina</h3>

                <p class="text-muted text-center">0110121126</p>

                <ul class="list-group list-group-unbordered mb-3">
                  <li class="list-group-item">
                    <b>Domisili</b> <a class="float-right">Depok</a>
                  </li>
                  <li class="list-group-item">
                    <b>Nomor</b> <a class="float-right">089663257164</a>
                  </li>
                  <li class="list-group-item">
                    <b>Jobdec</b> <a class="float-right">suplier</a>
                  </li>
                </ul>

                <a href="#" class="btn btn-block " style="background-color: #F2623A; color: white;"><b>Setting</b></a>
              </div>
              <!-- /.card-body -->
      </div>
    </div>
  </div>
</div>

		<!-- Footer-->
    <footer class="bg-grey py-5">
            <div class="container px-4 px-lg-5"><div class="small text-center text-muted">Copyright &copy; 2022 - STT-NF</div></div>
        </footer>

	</div>
	
</body>	
</html>

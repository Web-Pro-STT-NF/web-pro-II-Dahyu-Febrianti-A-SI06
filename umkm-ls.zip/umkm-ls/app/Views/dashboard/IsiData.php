<?php
$data_table1 = array (
  "nama" => 'Anita Rahmania', 
  "Jenis_kelamin" => 'Wanita',
  "Domisili" => 'jln. cendrawasih.08,Jakarta selatan',
  "Nomer_WA" => '098765467890',
  "Merk_Laptop" => 'Acer',
  "Type Ram" => '500gb',
  "Kondisi Laptop" => 'Error',
  "Harga yang ditawarkan" => 'Rp 3.000.000'
);

$data_table2 = array (
  "nama" => 'Anton Bahruddin', 
  "Jenis_kelamin" => 'Pria',
  "Domisili" => 'jln. Moh,Hatta, Bandung',
  "Nomer_WA" => '089786548909',
  "Merk_Laptop" => 'Dell',
  "Type Ram" => '100gb',
  "Kondisi Laptop" => 'Normal',
  "Harga yang ditawarkan" => 'Rp 8.000.000'
);

$gabungarray = array($data_table1, $data_table2);

//print result array
echo "<pre>";
print_r($gabungarray);
echo "<pre>";
?>
<?php

namespace App\Controllers;

use App\Models\DosenModel;

class Dosen extends BaseController
{
    public function index()
    {
        //object model dosen
        $this->dsn1 = new DosenModel();
        $this->dsn2 = new DosenModel();
        $this->dsn3 = new DosenModel();

        //memberikan nilai kepada object
        $this->dsn1->id = 1;
        $this->dsn1->nama = "Dahyu";
        $this->dsn1->nidn = "0123456789";
        $this->dsn1->gender = "P";
        $this->dsn1->pendidikan = "STT Terpadu Nurul Fikri";

        $this->dsn2->id = 2;
        $this->dsn2->nama = "Febrianti";
        $this->dsn2->nidn = "0123456789";
        $this->dsn2->gender = "P";
        $this->dsn2->pendidikan = "STT Terpadu Nurul Fikri";

        $this->dsn3->id = 1;
        $this->dsn3->nama = "Ambarisna";
        $this->dsn3->nidn = "0123456789";
        $this->dsn3->gender = "P";
        $this->dsn3->pendidikan = "STT Terpadu Nurul Fikri";

        $list_dsn = [$this->dsn1, $this->dsn2, $this->dsn3];
        $data['list_dsn'] = $list_dsn;

        //return sebuah view dan mengirimkan sebuah data array
        return view('dosen/index', $data);
    }
}
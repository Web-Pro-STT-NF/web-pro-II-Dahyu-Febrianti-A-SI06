<?php

namespace App\Models;

use CodeIgniter\Model;

class MataKuliahModel extends Model
{
    
    //Properti
    public $id;
    public $kode;
    public $nama;
    public $sks;

}
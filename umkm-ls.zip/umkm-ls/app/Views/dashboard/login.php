<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Log in</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<style>
	* {
  font-family: "Poppins", sans-serif;
}
body {
  background-color: #ece3c6;
}

@media (max-width: 992px) {
  img.foto {
    width: 60px;
  }
}
@media (min-width: 576px) {
  img.foto {
    width: 80px;
  }
}

@media (min-width: 768px) {
  img.foto {
    width: 100px;
  }
}
</style>
	
<script>
	function validasi() {
		var user = document.getElementById("username").value;
		var pass = document.getElementById("password").value;
		if (user == "" && pass == "") {
			alert('Username / Password Tidak Boleh Kosong');
			return false;
		}
		else if (pass.length < 6){
			alert('Password Kurang Dari 6');
			return false;
		}
		else if (user == "Laptop" && pass == "Second"){
			window.location = "pemesanan.php";
			return false;
		}else{
			alert("Username / Password Anda Salah, Coba Lagi");
		}
		}
</script>
	
</head>
	
<body>	 


<div  class="hold-transition login-page" style="background-color:#ece3c6;">
<div class="login-box">
  <div class="login-logo">
    <a><h2>Login</h2></a>
  </div>
  <!-- /.login-logo -->
  <div class="card" style="background-color: #FFFFFF;">
    <div class="card-body login-card-body" style="background-color: #FFFFFF;">
      <p class="login-box-msg" style="color: white;">Sign in to start your session</p>

      <form action="index3.html" method="post">
        <div class="input-group mb-3">
			<input type="text" placeholder="Username" class="form-control" name="username" id="username" required />
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-user-alt" style="color: white;"></span>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
			<input type="password" placeholder="Password" class="form-control" name="password" id="password" required />
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock" style="color: white;"></span>
            </div>
          </div>
        </div>
        <div class="row text-center">
		<!-- /.col -->
          <div class="col-4">
			  <input type="submit" class="btn btn-block" onClick="return validasi()" style="background-color: #F2623A; color: white" value="Sign In">
          </div>
          <!-- /.col -->
          <div class="col-8">
            <div class="icheck-primary">
              <label for="remember">
                <a href="pemesanan.php" class="text-center" style="color: #F2623A;">Registrasi User</a>
              </label>
            </div>
          </div>

        </div>
      </form>
		
    </div>
	  <p class="login-box-msg" style="color: black;">Info Login</p>
	  <p class="login-box-msg" style="color: black;">Username : Laptop</p>
	  <p class="login-box-msg" style="color: black;">Password : Second</p>
	  
    <!-- /.login-card-body -->
  </div>
</div>
	</div>
        <!-- Footer-->
        <footer class="bg-grey py-5">
            <div class="container px-4 px-lg-5"><div class="small text-center text-muted">Copyright &copy; 2022 - STT-NF</div></div>
        </footer>
</body>
</html>


<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="style1.css">

<div>
  <section class="font">
  <h1>Cara Jual Laptop Disini</h1>
</section>
</div>
<hr>

  <form action="Isi Data.php" method="$_Post">
<div>
  <article class="font2">
      <h6>Data Client</h6>
</article>
</div>
<br>

<div>
  <section class=form-client>
  <form action="Isi Data.php" method="$_Post">

  <div class="form-group row">
    <label for="Nama" class="col-4 col-form-label">Nama</label>
    <div class="col-8">
      <input id="text" name="nama" type="text" class="form-control">
    </div>
  </div>
  <br>

  <div class="form-group row">
    <label class="col-4">Jenis Kelamin</label>
    <div class="col-8">
      <div class="custom-control custom-radio custom-control-inline">
        <input name="gender" id="radio_0" type="radio" class="custom-control-input" value="Pria">
        <label for="radio_0" class="custom-control-label">Pria</label>
      </div>
      <div class="custom-control custom-radio custom-control-inline">
        <input name="gender" id="radio_1" type="radio" class="custom-control-input" value="Wanita">
        <label for="radio_1" class="custom-control-label">Wanita</label>
      </div>
    </div>

  </div>
  <div class="form-group row">
    <label for="textarea" class="col-4 col-form-label">Domisili</label>
    <div class="col-8">
      <textarea id="domisili" name="domisili" cols="40" rows="3" class="form-control"></textarea>
    </div>
  </div>


  <div class="form-group row">
    <label for="text" class="col-4 col-form-label">No WA Aktif</label>
    <div class="col-8">
      <input id="nomer" name="nomer" type="nomer" class="form-control">
    </div>
  </div>


  <div class="form-group row">
    <label class="col-4 col-form-label" for="select">Merk Laptop</label>
    <div class="col-8">
      <select id="merk" name="merk" class="custom-select">
        <option value="ASUS">ASUS</option>
        <option value="Acer">Acer</option>
        <option value="Dell">Dell</option>
        <option value="HP">HP</option>
        <option value="Lenovo">Lenovo</option>
        <option value="Apple">Apple</option>
        <option value="Samsung">Samsung</option>
      </select>
    </div>
  </div>


  <div class="form-group row">
    <label for="text" class="col-4 col-form-label">Type Ram</label>
    <div class="col-8">
      <input id="Ram" name="Ram" placeholder="Misal:  2gb, 500gb" type="text" class="form-control">
    </div>
  </div>
  <div class="form-group row">
    <label for="text" class="col-4 col-form-label">Type Laptop</label>
    <div class="col-8">
      <input id="text" name="typelaptop" placeholder="Misal:  A43s, G40, X453" type="text" class="form-control">
    </div>
  </div>


  <div class="form-group row">
    <label for="text" class="col-4 col-form-label">Kelengkapan</label>
    <div class="col-8">
      <input id="kelengkapan" name="kelengkapan" placeholder="Misal: Dusbox, Nota,tas" type="text" class="form-control">
    </div>
  </div>


  <div class="form-group row">
    <label class="col-4">Kondisi Laptop</label>
    <div class="col-8">
      <div class="custom-control custom-checkbox custom-control-inline">
        <input name="KondisiLaptop" id="Kondisi Laptop_0" type="checkbox" class="custom-control-input" value="Normal">
        <label for="Kondisi Laptop_0" class="custom-control-label">Normal</label>
      </div>
      <div class="custom-control custom-checkbox custom-control-inline">
        <input name="KondisiLaptop" id="Kondisi Laptop_1" type="checkbox" class="custom-control-input" value="Mati">
        <label for="Kondisi Laptop_1" class="custom-control-label">Mati</label>
      </div>
      <div class="custom-control custom-checkbox custom-control-inline">
        <input name="KondisiLaptop" id="Kondisi Laptop_2" type="checkbox" class="custom-control-input" value="Rusak">
        <label for="Kondisi Laptop_2" class="custom-control-label">Rusak</label>
      </div>
      <div class="custom-control custom-checkbox custom-control-inline">
        <input name="KondisiLaptop" id="Kondisi Laptop_3" type="checkbox" class="custom-control-input" value="Error">
        <label for="Kondisi Laptop_3" class="custom-control-label">Error</label>
      </div>
    </div>
  </div>


  <div class="form-group">
				<label>Upload Foto :</label>
				<input type="file" name="foto" required="required">
				<p style="color: blue">Ekstensi yang diperbolehkan .png | .jpg | .jpeg | .gif</p>
			</div>
  </div>


  <div class="form-group row">
    <label for="select1" class="col-4 col-form-label">Harga yang di ajukan</label>
    <div class="col-8">
      <select id="harga" name="harga" class="custom-select">
        <option value="Rp ">Rp 3.000.000</option>
        <option value="Rp">Rp 5.000.000</option>
        <option value="Rp">Rp 8.000.000</option>
      </select>
      <br>
      <br>
      <br>
    </div>
    <div class="form-group row">
    <div class="offset-4 col-8">
      <input name="submit" type="submit" class="btn btn-primary">SUMBIT</input>
    </div>
  </div>
  <div class="form-group row">
    <div class="offset-4 col-8">
      <input name="reset" type="reset" class="btn btn-primary">RESET</input>
    </div>
  </div>
</form>
<br>
<br>
<br>
<br>
</div>
</head>
<body>
<div class="font4">
      <b>kami akan infokan taksiran harganya</b>
    </div>
</section>

<div>
  <article class="col-5">
    <h4>Persyaratan yang bisa kami terima</h4>
    <aside>
      1. Milik Sendiri/Perorangan
      <br>
      2. Wajib menyertakan copy KTP/SIM
      <br>
      3. BUKAN HASIL KRIMINAL (Pencurian, perampasan, penipuan,dll)
      <br>
      4. Bukan type terlalu lawas atau jadul
      <br>
      5. Bukan Laptop Built-up
      <br>
      6. Bukan milik perusahaan/Teman/saudara
      <br>
      7. Tidak dalam masa kredit (belum lunas)
      <br>
      8. Tidak dalam masa jaminan atau gadai
      <br>
    </aside>
  </article>
</div>
</body>
</html>


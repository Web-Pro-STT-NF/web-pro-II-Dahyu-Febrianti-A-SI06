<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tabel HTML</title>
    <style>
        table, th, td{
            border-width: 1px;
            border-style: solid;
            border-color: #F2623A;
            border-collapse: collapse;
            margin: 10px;
            padding: 10px;
            text-align: center;
        }

        th{
            background-color: #F2623A;
            color: black;
        }

        td{
            background-color: #ffffff;
        }
    </style>

</head>
<body>
  <h3>Data Client Yang Menjual Laptop</h3>
    <table>
        <tr>
            <th>No </th>
            <th>Full name </th>
            <th>Email address </th>
            <th>Phone number </th>
            <th>Gender </th>
            <th>Domisili </th>
            <th>Action </th>
        </tr>
    
        <tr>
            <td>1</td>
            <td>Dahyu Febrianti Ambarisna</td>
            <td>dahyufbrianti@gmail.com</td>
            <td>08556465368</td>
            <td>Perempuan</td>
            <td>Bandung</td>
            <td><button type="button" class="btn btn-primary">Edit</button><button type="button" class="btn btn-danger">Hapus</button></td>
        </tr>
        <tr>
            <td>2</td>
            <td>Eka Ahmalia</td>
            <td>ekaahmalia@gmail.com</td>
            <td>08556465368</td>
            <td>Perempuan</td>
            <td>Depok</td>
            <td><button type="button" class="btn btn-primary">Edit</button><button type="button" class="btn btn-danger">Hapus</button></td>
        </tr>
    </table>
</body>
</html>
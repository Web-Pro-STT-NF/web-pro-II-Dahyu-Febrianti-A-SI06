<?php

namespace App\Controllers;

use App\Models\MahasiswaModel;

class Mahasiswa extends BaseController
{
    public function index()
    {
        //object model mahasiswa
        $this->mhs1 = new MahasiswaModel();
        $this->mhs2 = new MahasiswaModel();
        $this->mhs3 = new MahasiswaModel();

        //memberikan nilai kepada object
        $this->mhs1->id = 1;
        $this->mhs1->nama = "Dahyu";
        $this->mhs1->nim = "0110121125";
        $this->mhs1->gender = "P";
        $this->mhs1->tmp_lahir = "Bandung";
        $this->mhs1->tgl_lahir = "2 Februari 2003";
        $this->mhs1->ipk = 3.86;

        $this->mhs2->id = 2;
        $this->mhs2->nama = "Febrianti";
        $this->mhs2->nim = "0110121125";
        $this->mhs2->gender = "P";
        $this->mhs2->tmp_lahir = "Bandung";
        $this->mhs2->tgl_lahir = "2 Februari 2003";
        $this->mhs2->ipk = 3.86;

        $this->mhs3->id = 3;
        $this->mhs3->nama = "Ambarisna";
        $this->mhs3->nim = "0110121125";
        $this->mhs3->gender = "P";
        $this->mhs3->tmp_lahir = "Bandung";
        $this->mhs3->tgl_lahir = "2 Februari 2003";
        $this->mhs3->ipk = 3.86;

        $list_mhs = [$this->mhs1, $this->mhs2, $this->mhs3];
        $data['list_mhs'] = $list_mhs;

        //return sebuah view dan mengirimkan sebuah data array
        return view('mahasiswa/index', $data);
    }
}
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tabel HTML</title>
    <style>
        table, th, td{
            border-width: 1px;
            border-style: solid;
            border-color: #F2623A;
            border-collapse: collapse;
            margin: 10px;
            padding: 10px;
            text-align: center;
        }

        th{
            background-color: #F2623A;
            color: black;
        }

        td{
            background-color: #ffffff;
        }
    </style>

</head>
<body>
  <h3>Data Client Yang Membeli Laptop</h3>
    <table>
        <tr>
            <th>No </th>
            <th>Full name </th>
            <th>Email address </th>
            <th>Phone number </th>
            <th>Gender </th>
            <th>Name product </th>
            <th>Booking date </th>
            <th>Message </th>
            <th>Action </th>
        </tr>
    
        <tr>
            <td>1</td>
            <td>Fani Hilwa Agustin</td>
            <td>fanihilwa@gmail.com</td>
            <td>08556465368</td>
            <td>Perempuan</td>
            <td>Laptop Asus</td>
            <td>2 Juli 2022</td>
            <td>Warna peach</td>
            <td><button type="button" class="btn btn-primary">Edit</button><button type="button" class="btn btn-danger">Hapus</button></td>
        </tr>
        <tr>
            <td>2</td>
            <td>Nashwa Putri Sabina</td>
            <td>nashwaputri@gmail.com</td>
            <td>08556465368</td>
            <td>Perempuan</td>
            <td>Laptop Acer</td>
            <td>4 Juli 2022</td>
            <td>Warna biru</td>
            <td><button type="button" class="btn btn-primary">Edit</button><button type="button" class="btn btn-danger">Hapus</button></td>
        </tr>
    </table>
</body>
</html>